import java.util.Iterator;
import java.util.NoSuchElementException;

public class Deque<Item> implements Iterable<Item> {

    private N first, last;
    private int size = 0;

    private class N {
        Item i;
        N n;
        N p;
    }    

    // construct an empty deque
    public Deque() {

    }

    // is the deque empty?
    public boolean isEmpty() {

        return size == 0;
    }

    // return the number of items on the deque
    public int size() {

        return size;
    }

    private void add(Item item, boolean fromFront) {

        if (item == null) {

            throw new IllegalArgumentException();
        }

        N old = fromFront ? first : last;

        N newNode = new N();
        newNode.i = item;

        if (fromFront) {

            newNode.n = old;

            first = newNode;
            if (old == null) {

                last = first;
            } else {
                old.p = first;
            }
        } else {

            last = newNode;
            if (old != null) {

                old.n = last;
                last.p = old;
            } else {

                first = last;
            }
        }

        size++;
    }

    // add the item to the front
    public void addFirst(Item item) {

        add(item, true);
    }

    // add the item to the back
    public void addLast(Item item) {

        add(item, false);
    }

    private Item remove(boolean fromFront) {

        if (isEmpty()) {

            throw new NoSuchElementException();
        }

        Item item = fromFront ? first.i : last.i;

        if (fromFront) {

            first = first.n;
            if (first == null) {

                last = null;
            } else {

                first.p = null;
            }
        } else {

            last = last.p;

            if (last == null) {

                first = null;
            } else {

                last.n = null;
            }
        }

        size--;

        return item;
    }

    // remove and return the item from the front
    public Item removeFirst() {

        return remove(true);
    }

    // remove and return the item from the back
    public Item removeLast() {

        return remove(false);
    }

    // return an iterator over items in order from front to back
    public Iterator<Item> iterator() {

        return new Iterator<Item>() {

            @Override
            public boolean hasNext() {

                return size > 0;
            }

            @Override
            public Item next() {

                if (!hasNext()) {

                    throw new NoSuchElementException();
                }
                return removeFirst();
            }

            public void remove() {

                throw new UnsupportedOperationException();
            }
        };
    }

    // unit testing (required)
    public static void main(String[] args) {

        Deque<String> dq = createTestCase();

        Iterator<String> strItr = dq.iterator();

        while (strItr.hasNext()) {

            System.out.print(strItr.next() + " ");
        }

        dq = createTestCase();

        System.out.println();
        while (!dq.isEmpty()) {
            System.out.print(dq.removeFirst() + " ");
            System.out.print(dq.removeLast() + " ");
        }
    }

    private static Deque<String> createTestCase() {

        Deque<String> dq = new Deque<String>();
        String[] str = { "C", "D", "E", "B", "A", "F" };

        boolean isFront = true;
        boolean added = false;

        for (String s : str) {

            boolean isFnt = added ? !isFront : isFront;

            if (isFnt) {

                dq.addFirst(s);
            } else {

                dq.addLast(s);
            }

            isFront = isFnt;
            added = !added;
        }

        return dq;
    }

}
